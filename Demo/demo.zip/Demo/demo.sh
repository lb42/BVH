#!/bin/bash


ant -f buildAnn.xml -DfileName=$1 
